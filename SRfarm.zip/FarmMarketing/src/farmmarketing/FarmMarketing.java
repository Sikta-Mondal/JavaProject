
package farmmarketing;

/**
 *
 * @author Dell
 */
public class FarmMarketing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        start_page sp=new start_page();
        sp.setLocationRelativeTo(null);
        sp.setVisible(true);
    }
    
}
